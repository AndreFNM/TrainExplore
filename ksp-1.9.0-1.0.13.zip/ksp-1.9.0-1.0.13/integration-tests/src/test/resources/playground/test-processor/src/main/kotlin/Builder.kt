package com.example.annotation

annotation class Builder
