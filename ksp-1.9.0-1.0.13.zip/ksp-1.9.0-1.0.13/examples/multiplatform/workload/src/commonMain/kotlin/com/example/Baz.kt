package com.example

class Baz {
    val bar = Foo().bar
}
