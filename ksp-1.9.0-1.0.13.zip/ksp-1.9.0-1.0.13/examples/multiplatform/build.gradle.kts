plugins {
    kotlin("multiplatform") apply false
}

subprojects {
    repositories {
        mavenCentral()
    }
}
