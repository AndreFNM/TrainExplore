class LinuxX64Main

fun main() {
}
