package com.google.devtools.ksp

@RequiresOptIn(
    message = "This API is experimental." +
        "It may be changed in the future without notice or might be removed."
)
@Retention(AnnotationRetention.BINARY)
annotation class KspExperimental
