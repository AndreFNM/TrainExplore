annotation class NeedsImpl
annotation class Impl

val x: AllImpls = AllImpls()

fun main() {
    println(x.toString())
}
