package com.example

class Bar {
    val baz = Foo().baz
}
