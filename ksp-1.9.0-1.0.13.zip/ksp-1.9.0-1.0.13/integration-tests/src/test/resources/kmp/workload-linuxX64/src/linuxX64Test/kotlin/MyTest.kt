@com.example.MyAnnotation
@ExperimentalMultiplatform
class MyTest
