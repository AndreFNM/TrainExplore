@NeedsImpl
interface K1
