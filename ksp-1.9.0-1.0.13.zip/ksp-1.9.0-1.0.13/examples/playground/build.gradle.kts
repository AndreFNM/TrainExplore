plugins {
    kotlin("jvm")
}

subprojects {
    repositories {
        mavenCentral()
    }
}
