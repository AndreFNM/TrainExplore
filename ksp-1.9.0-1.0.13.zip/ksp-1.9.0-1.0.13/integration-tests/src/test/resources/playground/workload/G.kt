package g

import com.example.annotation.Builder

@Builder
class G
