class JvmJs
