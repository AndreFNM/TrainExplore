import com.example.Bar
import com.example.Foo

fun main() {
    println(Bar().toString())
    println(Foo().toString())
}
