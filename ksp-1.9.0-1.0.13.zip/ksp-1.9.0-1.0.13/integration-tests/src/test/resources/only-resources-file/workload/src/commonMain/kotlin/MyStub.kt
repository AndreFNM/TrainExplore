class MyStub
